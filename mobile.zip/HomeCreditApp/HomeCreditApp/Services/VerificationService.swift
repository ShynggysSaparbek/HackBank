//
//  AuthorizationService.swift
//  HomeCreditApp
//
//  Created by Saparbek . on 16.10.2021.
//

import Foundation
class VerificationService {
    func sendVerification(verification: String,
                   completion: @escaping (Bool)->() ){
        let json: [String: Any] = ["token": verification]
        
        if let jsonData = try? JSONSerialization.data(withJSONObject: json) {
            print(json)
            completion(true)
            return
        }
        
        // create post request
        let url = URL(string: "https://usermanager.loca.lt/api/v1/verification")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let _ = data, error == nil else {
                print(error ?? "there is no data")
                completion(false)
                return
            }
            
            completion(true)
        }

        task.resume()
        
        
    }
}
