//
//  Verification.swift
//  HomeCreditApp
//
//  Created by Saparbek . on 16.10.2021.
//

import Foundation
enum RegistrationError: Error {
    case failedtoParseJson
    case networkinngError
}
class AuthorizationService {
    func sendPhone(phone: String,
                   completion: @escaping (Bool)->() ){
        
        // create post request
        var phone = phone
        phone = String(phone.dropFirst(2))
        phone = "8" + phone
        let urlString = "https://usermanager.loca.lt/api/v1/sms?phone=\(phone)&id=1"
        print(urlString)
        let url = URL(string: urlString)!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        // insert json data to the request

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let _ = data, error == nil else {
                print(error ?? "there is no data")
                completion(false)
                return
            }
            
            completion(true)
        }

        task.resume()
        
        
    }
}
