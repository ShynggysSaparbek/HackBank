//
//  RegistrationService.swift
//  HomeCreditApp
//
//  Created by Saparbek . on 16.10.2021.
//

import Foundation
class Registration{
    func send(iin: String, phone: String, completion: @escaping (Bool)->() ){
        let json: [String: Any] = ["iin": iin,
            "phoneNumber": phone]

        guard let jsonData = try? JSONSerialization.data(withJSONObject: json) else {
            completion(false)
            return
        }
        
        // create post request
        let url = URL(string: "https://usermanager.loca.lt/api/v1/sms")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        // insert json data to the request
        request.httpBody = jsonData

        let task = URLSession.shared.dataTask(with: request) { data, response, error in 
            guard let _ = data, error == nil else {
                print(error ?? "there is no data")
                completion(false)
                return
            }
            
            completion(true)
        }

        task.resume()
    }
}
