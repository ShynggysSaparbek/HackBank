//
//  shopsService.swift
//  HomeCreditApp
//
//  Created by Saparbek . on 17.10.2021.
//

import Foundation
class ShopsService {
    func send(completion: @escaping ([Shop])->() ){
        // create post request
        let url = URL(string: "https://usermanager.loca.lt/api/item?marketId=2&productId=5")!
        var request = URLRequest(url: url)

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                print(error ?? "there is no data")
                completion([])
                return
            }
            guard let tableData = try? JSONDecoder().decode([String].self, from: data) else {
                completion([])
                return
            }
            let shops = tableData.map { name in
                return Shop(name: name)
            }
            
            completion(shops)
        }
        task.resume()
    }
}
