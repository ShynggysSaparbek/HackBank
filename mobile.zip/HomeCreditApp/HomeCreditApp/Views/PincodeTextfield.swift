//
//  PincodeTextfield.swift
//  HomeCreditApp
//
//  Created by Saparbek . on 16.10.2021.
//

import UIKit

class PinCodeTextField: UITextField {
    private var numberOfDigits = 4
    
    
    private var isConfigured: Bool = false
    private var didEnterLastDigit: ((String)->())?
    
    private let digitsStackView = UIStackView()
    private lazy var digitLabels: [UILabel] = {
        var labels: [UILabel] = []
        for index in 0..<numberOfDigits {
            labels.append(UILabel())
        }
        return labels
    }()
    
    private lazy var tapRecognizer: UITapGestureRecognizer = {
        let recognizer = UITapGestureRecognizer()
        recognizer.addTarget(self, action: #selector(becomeFirstResponder))
        return recognizer
    }()
    
    func configureView(didEnterLastDigit: @escaping ((String)->())){
        self.didEnterLastDigit = didEnterLastDigit
        
        guard isConfigured == false else {
            return
        }
        isConfigured = true
        
        addGestureRecognizer(tapRecognizer)
        
        configureTextfieldAttributes()
        
        configureDigitsStackView()
    }
    
    private func configureDigitsStackView(){
        addSubview(digitsStackView)
        
        configureDigitsStackViewAttributes()
        
        configureDigitsStackViewConstraints()
        
        configureDigitLabels()
    }
    
    private func configureDigitLabels(){
        for index in 0..<numberOfDigits {
            configureDigitLabel(with: index)
        }
    }
    
    private func configureDigitLabel(with index: Int){
        let digitLabel = digitLabels[index]
        
        digitsStackView.addArrangedSubview(digitLabel)
        
        configureDigitLabelAttributes(digitLabel: digitLabel)
        configureDigitLabelConstraint(digitLabel: digitLabel)
        
    }
    
    private func configureDigitsStackViewAttributes(){
        digitsStackView.alignment = .fill
        digitsStackView.distribution = .fillEqually
        digitsStackView.axis = .horizontal
        digitsStackView.spacing = 10
    }
    
    private func configureTextfieldAttributes(){
        tintColor = .clear
        textColor = .clear
        backgroundColor = .clear
        borderStyle = .none
        keyboardType = .numberPad
        textContentType = .oneTimeCode
        
        addTarget(self, action: #selector(textDidChange), for: .editingChanged)
    }
    
    private func configureDigitLabelAttributes(digitLabel: UILabel){
        
        digitLabel.backgroundColor = .white
        digitLabel.isUserInteractionEnabled = false
        
        
        digitLabel.textAlignment = .center
        digitLabel.font = font
        
        digitLabel.layer.cornerRadius = 10
        digitLabel.clipsToBounds = true
        digitLabel.layer.masksToBounds = true
    }
    
    private func configureDigitsStackViewConstraints(){
        digitsStackView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            digitsStackView.topAnchor.constraint(equalTo: topAnchor),
            digitsStackView.bottomAnchor.constraint(equalTo: bottomAnchor),
            digitsStackView.trailingAnchor.constraint(equalTo: trailingAnchor),
            digitsStackView.leadingAnchor.constraint(equalTo: leadingAnchor)
        ])
    }
    
    private func configureDigitLabelConstraint(digitLabel: UILabel){
        digitLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            digitLabel.heightAnchor.constraint(equalToConstant: 100)
        ])
    }
    
    
    @objc private func textDidChange(){
        guard let text = text else {
            return
        }
        let filteredText = String(text.prefix(numberOfDigits))
        self.text = filteredText
        for digitLabel in digitLabels {
            digitLabel.text = " "
        }
        
        for (index, char) in filteredText.enumerated() {
            digitLabels[index].text = String(char)
        }
        
        if text.count == digitLabels.count{
            didEnterLastDigit?(text)
        }
    }
}
