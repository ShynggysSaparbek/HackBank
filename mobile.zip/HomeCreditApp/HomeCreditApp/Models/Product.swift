//
//  Product.swift
//  HomeCreditApp
//
//  Created by Saparbek . on 17.10.2021.
//

import Foundation
struct Product {
    var name: String
    var imageUrl: String
    
}
