//
//  Market.swift
//  HomeCreditApp
//
//  Created by Saparbek . on 17.10.2021.
//

import Foundation
struct Shop {
    var name: String
}
