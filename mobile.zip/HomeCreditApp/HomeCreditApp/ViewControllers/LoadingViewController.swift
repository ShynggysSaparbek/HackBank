//
//  LoadingViewController.swift
//  HomeCreditApp
//
//  Created by Saparbek . on 17.10.2021.
//

import UIKit
class LoadingViewController: UIViewController{
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [weak self] in
            self?.performSegue(withIdentifier: "showFinalDecision", sender: nil)
        }
    }
}
