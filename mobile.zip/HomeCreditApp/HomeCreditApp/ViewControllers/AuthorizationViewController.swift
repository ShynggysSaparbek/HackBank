//
//  RegistrationViewController.swift
//  HomeCreditApp
//
//  Created by Saparbek . on 16.10.2021.
//

import UIKit
class AuthorizationViewController: ViewController {
    var authorizationService: AuthorizationService!
    
    @IBOutlet weak var phoneTextfield: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        authorizationService = AuthorizationService()
    }
    
    @IBAction func didPressButton(_ sender: Any) {
        
        guard let phone = phoneTextfield.text else {
            return
        }
        
        authorizationService.sendPhone(phone: phone) { [weak self] isSuccesfull in
            guard isSuccesfull else {
                return
            }
        }
        
        self.performSegue(withIdentifier: "verificationSegue", sender: nil)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let dest = segue.destination as? VerificationViewController else {
            return
        }
        
        dest.phone = phoneTextfield.text!
    }
}
