//
//  ShopTableViewController.swift
//  HomeCreditApp
//
//  Created by Saparbek . on 17.10.2021.
//

import UIKit
class ShopTableViewController: ViewController {
    @IBOutlet weak var tableview: UITableView!
    var shops: [Shop] = [Shop(name: "Technodom"), Shop(name: "Zara")]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableview.delegate = self
        tableview.dataSource = self
        
        tableview.separatorStyle = .none
    }
}

extension ShopTableViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shops.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "shopCell")!
        
        cell.textLabel?.text = shops[indexPath.row].name
        cell.textLabel?.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 43
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "chosenStoreToBuy", sender: nil)
    }
    
}
