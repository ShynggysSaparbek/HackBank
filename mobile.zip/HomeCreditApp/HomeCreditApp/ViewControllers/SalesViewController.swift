//
//  SalesViewController.swift
//  HomeCreditApp
//
//  Created by Saparbek . on 17.10.2021.
//

import UIKit
class SalesViewController: UIViewController {
    @IBOutlet weak var contentView: UIImageView!
    
    @IBOutlet weak var cardButton: UIButton!
    @IBOutlet weak var rassrochkaButton: UIButton!
    @IBOutlet weak var creditButton: UIButton!
    
    
    @IBOutlet weak var ratio: NSLayoutConstraint!
    
    @IBAction func didSelectCard(_ sender: Any) {
        
        contentView.image = nil
    }
    
    @IBAction func didSelectRassrochka(_ sender: Any) {
        contentView.image = UIImage(named: "ressrochka")
        
        deselectAll()
        
        selectButton(button: rassrochkaButton)
    }
    
    @IBAction func didSelectCredit(_ sender: Any) {
        contentView.image = UIImage(named: "credits")
        
        deselectAll()
        
        selectButton(button: creditButton)
    }
    
    func deselectAll(){
        deselectButton(button: cardButton)
        deselectButton(button: rassrochkaButton)
        deselectButton(button: creditButton)
    }
    
    func deselectButton(button: UIButton){
        button.setTitleColor(UIColor(red: 161/256.0,
                                     green: 161/256.0,
                                     blue: 161/256.0,
                                     alpha: 1), for: .normal)
        button.backgroundColor = UIColor(red: 217/256.0,
                                         green: 219/256.0,
                                         blue: 227/256.0,
                                         alpha: 1)
    }
    
    func selectButton(button: UIButton){
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = UIColor(red: 206/256.0,
                                         green: 19/256.0,
                                         blue: 31/256.0,
                                         alpha: 1)
    }
}
