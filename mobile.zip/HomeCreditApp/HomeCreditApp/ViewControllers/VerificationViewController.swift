//
//  VerificationViewController.swift
//  HomeCreditApp
//
//  Created by Saparbek . on 16.10.2021.
//

import UIKit
class VerificationViewController: UIViewController {
    var authorizationnService: AuthorizationService!
    var verificationService: VerificationService!
    
    var phone: String = "87017002000"
    
    @IBOutlet weak var pincodeTextfield: PinCodeTextField!
    @IBOutlet weak var recallButton: UIButton!
    @IBOutlet weak var alertLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pincodeTextfield.configureView(didEnterLastDigit: didEnterLastDigit)
        authorizationnService = AuthorizationService()
        verificationService = VerificationService()
        alertLabel.text = "Код отправлен на номер \(phone)"
        
        recallButton.isHidden = true
        // disableForAMinute()
    }
    
    func disableForAMinute(){
        recallButton.isEnabled = false
        self.recallButton.setTitle("Запросить через 00:60", for: .normal)
        
        for i in (1...59).reversed() {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(60 - i)) { [weak self] in
                guard let self = self else {
                    return
                }
                self.recallButton.setTitle("Запросить через 00:" + String(i), for: .normal)
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + Double(60)) { [weak self] in
            guard let self = self else {
                return
            }
            self.recallButton.setTitle("Запросить", for: .normal)
            self.recallButton.isEnabled = true
        }
    }
    
    @IBAction func recallButtonPressed(_ sender: Any) {
        disableForAMinute()
    }
    
    lazy var didEnterLastDigit: (String)->() = { [weak self] pincode in
        self?.performSegue(withIdentifier: "iinSegue", sender: nil)
    }
}
