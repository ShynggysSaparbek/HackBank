//
//  MarketPlaceViewController.swift
//  HomeCreditApp
//
//  Created by Saparbek . on 16.10.2021.
//

import UIKit
class MarketPlaceViewController: UIViewController {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        //searchBar.delegate = self
        //collectionView.delegate = self
        
        //configureSearchBar()
        
        
    }
}

extension MarketPlaceViewController: UISearchBarDelegate {
    func configureSearchBar(){
        searchBar.layer.borderWidth = 1
        searchBar.layer.borderColor = CGColor(red: 0, green: 0, blue: 0, alpha: 0)
    }
    
    func configureSearchBarTextFlied(){
        guard let txfSearchField = searchBar.value(forKey: "_searchField") as? UITextField else {
            return
        }
        
        txfSearchField.borderStyle = .none
        txfSearchField.backgroundColor = .white
    }
}

extension MarketPlaceViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 16
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 16
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let screenWidth = Int(UIScreen.main.bounds.size.width)
        
        let width = (screenWidth - 16 - 23 - 23) / 2
        let height = 91
        return CGSize(width: width, height: height)
    }
}
