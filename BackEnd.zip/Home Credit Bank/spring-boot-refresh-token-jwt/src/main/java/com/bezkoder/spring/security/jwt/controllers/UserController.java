package com.bezkoder.spring.security.jwt.controllers;

import com.bezkoder.spring.security.jwt.models.Client;
import com.bezkoder.spring.security.jwt.payload.request.SignupRequest;
import com.bezkoder.spring.security.jwt.repository.ClientRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/client")
public class UserController {
    private final ClientRepository clientRepository;

    public UserController(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }


    @PostMapping("/signup")
    public ResponseEntity<?> registerUser( @RequestBody SignupRequest signUpRequest) {
        clientRepository.save(new Client(signUpRequest.getPhone(),signUpRequest.getIin()));
        return ResponseEntity.ok("ok");
    }
}
