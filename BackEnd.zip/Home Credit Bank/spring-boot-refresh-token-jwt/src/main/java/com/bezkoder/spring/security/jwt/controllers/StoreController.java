package com.bezkoder.spring.security.jwt.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/store")
public class StoreController {
    @GetMapping
    public ResponseEntity<String> getNearStore(@RequestParam(value = "longitude",required = false) String longitude,
                                               @RequestParam(value = "latitude",required = false) String latitude) {
        return new ResponseEntity<>("[\"Sulpak\",\"Technodom\"]", HttpStatus.OK);
    }
}
