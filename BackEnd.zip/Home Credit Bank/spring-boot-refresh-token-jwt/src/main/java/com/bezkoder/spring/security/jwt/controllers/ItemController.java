package com.bezkoder.spring.security.jwt.controllers;

import com.bezkoder.spring.security.jwt.models.Item;
import com.bezkoder.spring.security.jwt.payload.ItemDto;
import com.bezkoder.spring.security.jwt.repository.ItemRepository;
import net.kaczmarzyk.spring.data.jpa.domain.Equal;
import net.kaczmarzyk.spring.data.jpa.web.annotation.And;
import net.kaczmarzyk.spring.data.jpa.web.annotation.Spec;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/item")
public class ItemController {
    private final ItemRepository itemRepository;

    public ItemController(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

//    @Transactional
//    @GetMapping
//    @ResponseStatus(HttpStatus.OK)
//    public ResponseEntity<List<ItemDto>> findItems(
//            @And({
//                    @Spec(path = "producer", params = "producer", spec = Equal.class),
//                    @Spec(path = "category", params = "category", spec = Equal.class),
//                    @Spec(path = "name", params = "name", spec = Equal.class),
//                    @Spec(path = "storename", params = "storename", spec = Equal.class)
//            })
//            Specification<Item> customerSpec,
//            Sort sort,
//            Pageable pageable) {
//        return new ResponseEntity<>(itemRepository.findAll(customerSpec, sort).stream()
//                .map(ItemDto::new).collect(Collectors.toList()), HttpStatus.OK);
//    }

    @GetMapping
    public ResponseEntity<ItemDto> getItem(@RequestParam(value = "marketId",required = false) String storeId,
                                               @RequestParam(value = "productId",required = false) String itemId) {
        return new ResponseEntity<ItemDto>(new ItemDto(itemRepository.findById(3L).get()), HttpStatus.OK);
    }
//    @GetMapping
//    public ResponseEntity<List<ItemDto>> getAllItems() {
//        List<ItemDto> itemDtos = new ArrayList<>();
//        for(Item item: itemRepository.findAll())
//            itemDtos.add(new ItemDto(item));
//        return new ResponseEntity<>(itemDtos, HttpStatus.OK);
//    }
}
