package com.bezkoder.spring.security.jwt.payload;

import com.bezkoder.spring.security.jwt.models.Item;

public class ItemDto {
    private String name;

    private String  price;

    private String producer;

    private String category;

    private String categoryurl;

    private String storename;

    private String photo;


    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setProducer(String producer) {
        this.producer = producer;
    }


    public void setCategory(String category) {
        this.category = category;
    }

    public void setCategoryurl(String categoryurl) {
        this.categoryurl = categoryurl;
    }

    public void setStorename(String storename) {
        this.storename = storename;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }


    public ItemDto(Item item) {
        this.name = item.getName();
        this.price = item.getPrice();
        this.producer = item.getProducer();
        this.category = item.getCategory();
        this.categoryurl = item.getCategoryurl();
        this.storename = item.getStorename();
        this.photo = item.getPhoto();
    }

    public String getName() {
        return name;
    }

    public String  getPrice() {
        return price;
    }

    public String getProducer() {
        return producer;
    }

    public String getCategory() {
        return category;
    }

    public String getCategoryurl() {
        return categoryurl;
    }

    public String getStorename() {
        return storename;
    }

    public String getPhoto() {
        return photo;
    }
}
