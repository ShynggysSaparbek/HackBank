package com.bezkoder.spring.security.jwt.sms;



public interface SmsSender {

    void sendSms(String phone, String notif);

    // or maybe void sendSms(String phoneNumber, String message);
}
