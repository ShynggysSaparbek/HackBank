package com.bezkoder.spring.security.jwt.models;

import javax.persistence.*;

@Entity
@Table(	name = "items")
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String price;

    private String producer;

    private String producerurl;

    private String category;

    private String categoryurl;

    private String storename;

    private String photo;

    private String description;

    private String rating;

    private String identity;

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }

    public String getProducer() {
        return producer;
    }

    public String getProducerurl() {
        return producerurl;
    }

    public String getCategory() {
        return category;
    }

    public String getCategoryurl() {
        return categoryurl;
    }

    public String getStorename() {
        return storename;
    }

    public String getPhoto() {
        return photo;
    }

    public String getDescription() {
        return description;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setProducer(String producer) {
        this.producer = producer;
    }

    public void setProducerurl(String producerurl) {
        this.producerurl = producerurl;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setCategoryurl(String categoryurl) {
        this.categoryurl = categoryurl;
    }

    public void setStorename(String storename) {
        this.storename = storename;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
