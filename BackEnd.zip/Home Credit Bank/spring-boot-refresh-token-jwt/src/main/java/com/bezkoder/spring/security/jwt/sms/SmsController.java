package com.bezkoder.spring.security.jwt.sms;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/sms")
@ApiModel(description = "Rest Controller для отправки смс на телефон")
public class SmsController {

    private final Service service;

    @Autowired
    public SmsController(Service service) {
        this.service = service;
    }

    @GetMapping
    @ApiOperation(value = "Создать отправить смс")
    public void sendSms(@RequestParam(value = "phone") String phone,
                        @RequestParam(value = "id") String id) {

        if (id.equals("1")) {
            service.sendSms("+7"+phone.substring(1), "9657");
        } else{
            service.sendSms("+7"+phone.substring(1), "Ваш кредит одобрен");
        }
    }

}
