package com.example.demo.domain.dto;

public class SignupRequest {
    private String iin;
    private String phone;

    public SignupRequest(String iin, String phone) {
        this.iin = iin;
        this.phone = phone;
    }

    public String getIin() {
        return iin;
    }

    public void setIin(String iin) {
        this.iin = iin;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
