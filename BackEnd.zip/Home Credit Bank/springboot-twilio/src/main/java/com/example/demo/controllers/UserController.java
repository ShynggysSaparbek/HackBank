package com.example.demo.controllers;

import com.example.demo.domain.User;
import com.example.demo.domain.dto.SignupRequest;
import com.example.demo.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/user")
public class UserController {
    private final UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@Valid @RequestBody SignupRequest signUpRequest) {
        userRepository.save(new User(signUpRequest.getIin(),signUpRequest.getPhone()));
        return ResponseEntity.ok("ok");
    }
}
